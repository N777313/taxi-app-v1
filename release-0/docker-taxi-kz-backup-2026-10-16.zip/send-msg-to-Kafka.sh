printf 'Taxi-KZ M0 test message\n' | \
docker compose exec -T kafka \
  /opt/kafka/bin/kafka-console-producer.sh \
  --bootstrap-server kafka:9092 \
  --topic taxi-m0-test
