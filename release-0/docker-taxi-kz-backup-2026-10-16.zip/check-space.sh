docker compose exec web python manage.py check --database default
docker compose ps
df -h /
