cd ~/Desktop/docker-project/docker-taxi-kz

echo "=== Migration status ==="
docker compose exec web python manage.py showmigrations

echo
echo "=== Environment variable names in .env ==="
grep -E '^[A-Z][A-Z0-9_]*=' .env | cut -d= -f1 | sort

echo
echo "=== Environment variable names in .env.example ==="
grep -E '^[A-Z][A-Z0-9_]*=' .env.example | cut -d= -f1 | sort

echo
echo "=== Disk space ==="
df -h /
