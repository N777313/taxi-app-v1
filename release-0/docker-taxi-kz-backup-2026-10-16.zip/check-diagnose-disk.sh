
echo "=== Размеры каталогов на системном разделе ==="
sudo du -xhd1 / 2>/dev/null | sort -h

echo
echo "=== Размеры каталогов пользователя ==="
du -xhd1 "$HOME" 2>/dev/null | sort -h

echo
echo "=== Крупные файлы на системном разделе (более 300 МБ) ==="
sudo find / -xdev -type f -size +300M \
  -printf '%s %p\n' 2>/dev/null |
  sort -n | tail -25 |
  numfmt --field=1 --to=iec

echo
echo "=== Использование inode ==="
df -i /
