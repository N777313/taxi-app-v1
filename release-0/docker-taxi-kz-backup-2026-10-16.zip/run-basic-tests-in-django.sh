docker compose exec web python manage.py test accounts rides config
