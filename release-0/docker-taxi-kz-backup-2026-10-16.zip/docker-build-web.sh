docker compose config --quiet
docker compose build web
