cd ~/Desktop/docker-project/docker-taxi-kz

echo "=== Containers ==="
docker compose ps

echo "=== Django health endpoint ==="
curl -i http://127.0.0.1:8000/health/

echo "=== Django database check ==="
docker compose exec web python manage.py check --database default

echo "=== Recent web logs ==="
docker compose logs --tail=60 web

echo "=== Free disk space ==="
df -h /

echo "=== Git ignores .env ==="
git check-ignore .env
