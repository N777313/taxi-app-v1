docker compose config --quiet
