
cd ~/Desktop/docker-project/docker-taxi-kz

if grep -q 'replace-with-a-random-secret' .env; then
  echo "ВНИМАНИЕ: Django SECRET_KEY остался шаблонным"
else
  echo "Django SECRET_KEY не совпадает с шаблоном"
fi

if grep -q 'replace-with-a-strong-password' .env; then
  echo "ВНИМАНИЕ: пароль PostgreSQL остался шаблонным"
else
  echo "Пароль PostgreSQL не совпадает с шаблоном"
fi
