cd ~/Desktop/docker-project/docker-taxi-kz

echo "=== .env ignored by Git ==="
git check-ignore -v .env

echo
echo "=== Environment files tracked by Git ==="
git ls-files .env .env.example

echo
echo "=== Git status ==="
git status --short
