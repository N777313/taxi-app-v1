docker image inspect taxi-kz-app:dev \
  --format '{{.Os}}/{{.Architecture}}'
