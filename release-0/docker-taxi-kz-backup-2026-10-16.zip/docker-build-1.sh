docker build -t taxi-kz-app:dev .
