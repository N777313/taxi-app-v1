sudo lsof +L1 2>/dev/null | head -40
