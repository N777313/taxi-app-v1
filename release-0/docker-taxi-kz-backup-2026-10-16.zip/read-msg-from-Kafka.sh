docker compose exec kafka \
  /opt/kafka/bin/kafka-console-consumer.sh \
  --bootstrap-server kafka:9092 \
  --topic taxi-m0-test \
  --from-beginning \
  --max-messages 1 \
  --timeout-ms 10000
