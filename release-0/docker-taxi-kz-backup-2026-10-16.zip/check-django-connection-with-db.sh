docker compose exec web python manage.py check --database default
