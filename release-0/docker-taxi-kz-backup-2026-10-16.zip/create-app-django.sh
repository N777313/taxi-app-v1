cd ~/Desktop/docker-project/docker-taxi-kz

docker compose exec web python manage.py startapp accounts
docker compose exec web python manage.py startapp rides
