
DOCKER_ROOT="$(docker info --format '{{.DockerRootDir}}')"

echo "Docker root: $DOCKER_ROOT"
df -h "$DOCKER_ROOT"
sudo du -xhd1 "$DOCKER_ROOT" 2>/dev/null | sort -h
