
echo "=== Docker data directory ==="
docker info --format '{{.DockerRootDir}}'

echo "=== Крупные каталоги корневого раздела ==="
sudo du -xhd1 / 2>/dev/null | sort -h

echo "=== Домашний каталог ==="
du -xhd1 "$HOME" 2>/dev/null | sort -h

echo "=== APT cache ==="
sudo du -sh /var/cache/apt/archives /var/lib/apt/lists 2>/dev/null

echo "=== Systemd journal ==="
sudo journalctl --disk-usage
