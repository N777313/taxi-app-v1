docker compose exec web python manage.py check --database default
docker compose exec web python manage.py test config
