docker network inspect taxi-kz_taxi_backend \
  --format '{{range .Containers}}{{println .Name}}{{end}}'

docker volume ls
df -h / /mnt/extra
docker system df
