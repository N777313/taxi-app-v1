echo "=== Docker directory links ==="
ls -ld /var/lib/docker /mnt/extra /mnt/extra/docker_data

echo "=== Filesystem for Docker paths ==="
findmnt -T /var/lib/docker
findmnt -T /mnt/extra/docker_data

echo "=== Docker storage ==="
docker info --format 'Root={{.DockerRootDir}} Driver={{.Driver}}'
