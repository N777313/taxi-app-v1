docker run --rm taxi-kz-app:dev
