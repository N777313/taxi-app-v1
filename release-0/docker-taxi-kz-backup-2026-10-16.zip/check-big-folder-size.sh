echo "=== Root directories ==="
sudo du -xhd1 / 2>/dev/null | sort -h

echo "=== Home directories ==="
du -xhd1 "$HOME" 2>/dev/null | sort -h

echo "=== Large files over 300 MB ==="
sudo find / -xdev -type f -size +300M \
  -printf '%s %p\n' 2>/dev/null |
  sort -n | tail -30 |
  numfmt --field=1 --to=iec
