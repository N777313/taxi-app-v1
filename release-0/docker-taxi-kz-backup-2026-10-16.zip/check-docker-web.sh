docker compose exec web python -c \
'import os; v=os.getenv("DJANGO_SECRET_KEY",""); print("DJANGO_SECRET_KEY:", "OK" if len(v)>=50 and "replace-with-" not in v else "CHECK REQUIRED")'
