docker compose exec web python manage.py makemigrations accounts rides
docker compose exec web python manage.py migrate
